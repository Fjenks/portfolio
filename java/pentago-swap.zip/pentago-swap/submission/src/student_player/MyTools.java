package student_player;

import boardgame.BoardState;


import java.util.Random;
import boardgame.Move;
import pentago_swap.PentagoCoord;
import pentago_swap.PentagoMove;
import pentago_swap.PentagoBoardState;
import pentago_swap.PentagoBoardState.Piece;
import pentago_swap.PentagoBoardState.Quadrant;

public class MyTools {
	
	public static int dangerSolve(PentagoBoardState boardState, PentagoMove myMove) {
		
		//This method is to check for immediate danger on the board by passing the opponent
		//to the method that checks for an immediate win possibility. If there is danger,
		//the agent searches through the current legal moves and processes them on a clone
		//until it finds one that has blocked the immediate danger. It then passes the index
		//of this solution to the main choose move method
		
		PentagoBoardState fakeState = (PentagoBoardState)boardState.clone();
    	fakeState.processMove(myMove);
    	int dangerCheck = MyTools.winCheck(fakeState,(boardState.getOpponent()));
    	
    	if(dangerCheck == -1) {
    		return -2;
    	}
    	int i = 0;
    	while(dangerCheck != -1&&i<boardState.getAllLegalMoves().size()) {
    		fakeState = (PentagoBoardState)boardState.clone();
    		myMove = boardState.getAllLegalMoves().get(i);
            fakeState.processMove(myMove);
            dangerCheck = MyTools.winCheck(fakeState,(boardState.getOpponent()));
            if(dangerCheck!=-1) {
            	i++;
            }
    	}
    	if(dangerCheck==-1) {
    		return i;
    	}
    	else {
    		return -1;
    	}
    	
	}

	public static int winCheck(PentagoBoardState boardState, int active) {
		
		//Algorithm processes all possible moves on a board state clone and if any result
		//in a win for the active player, returns the index of that move
		
		for(int i = 0;i<boardState.getAllLegalMoves().size();i++) {
			PentagoMove currentMove = boardState.getAllLegalMoves().get(i);
			PentagoBoardState fakeState = (PentagoBoardState)boardState.clone();
			fakeState.processMove(currentMove);
			if(fakeState.gameOver()==true&&fakeState.getWinner()==active) {
				return i;
			}
		}
		return -1;
	}

	public static int MinMax(PentagoBoardState boardState, PentagoMove move, int player, int active) {
		
		//Standard min max algorithm. If there is no immediate danger or win found, runs the
		//min max algorithm selecting the best score for the player and opponent at each level
		
		PentagoBoardState fakeState = (PentagoBoardState)boardState.clone();
		fakeState.processMove(move);
		if(fakeState.gameOver()==true) {
			if(fakeState.getWinner()==player) {
				return 1;
			}
			if(fakeState.getWinner()==active&&active!=player) {
				return -1;
			}
			else {
				return 0;
			}
		}
		int[] scores = new int[fakeState.getAllLegalMoves().size()];
		if(scores.length==0) {
			return 0;
		}
		for(int i = 0;i<fakeState.getAllLegalMoves().size();i++) {
			PentagoBoardState checkState = (PentagoBoardState)fakeState.clone();
			PentagoMove currentMove = fakeState.getAllLegalMoves().get(i);
			
			int score = MyTools.MinMax(checkState,currentMove, (1-boardState.getOpponent()), (1-boardState.getOpponent()));
			scores[i] = score;
			if(score == 1) {
				if(player==active) {
					return 1;
				}
			}
			else if(score == -1) {
				if(player!=active) {
					return -1;
				}
			}


		}
		return 0;
		
	}

	

}