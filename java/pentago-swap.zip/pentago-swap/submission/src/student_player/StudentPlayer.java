package student_player;

import java.util.ArrayList;

import boardgame.Move;



import pentago_swap.PentagoCoord;
import pentago_swap.PentagoMove;
import pentago_swap.PentagoPlayer;
import pentago_swap.PentagoBoardState;
import pentago_swap.PentagoBoardState.Piece;

/** A player file submitted by a student. */
public class StudentPlayer extends PentagoPlayer {

    /**
     * You must modify this constructor to return your student number. This is
     * important, because this is what the code that runs the competition uses to
     * associate you with your agent. The constructor should do nothing else.
     */
    public StudentPlayer() {
        super("260736081");
    }

    /**
     * This is the primary method that you need to implement. The ``boardState``
     * object contains the current state of the game, which your agent must use to
     * make decisions.
     */
    public Move chooseMove(PentagoBoardState boardState) {
    	Move myMove = boardState.getRandomMove();
    	
    	// Checks at the start of each turn if there is a way to immediately win the game
    	//If so, takes that move
    	
    	int goForTheKill = MyTools.winCheck(boardState, 1-boardState.getOpponent());
        if(goForTheKill!=-1) {
        	myMove = boardState.getAllLegalMoves().get(goForTheKill);
        }
        else {
        	
        	int avoidDanger = -1;
        	int[] scores = new int[boardState.getAllLegalMoves().size()];
        	for(int i = 0;i<boardState.getAllLegalMoves().size();i++) {
    			PentagoMove currentMove = boardState.getAllLegalMoves().get(i);
    			
    			//Before starting the min max algorithm on the current move, check if the
    			//move results in an immediate loss. If so, it instead picks a move that
    			//will ensure this loss does not happen.
    			
    			int dangerCheck = MyTools.dangerSolve(boardState, currentMove);
        		if(dangerCheck==-1) {
        			continue;
        		}
        		if(dangerCheck==-2) {

        			// Runs the modified min max algorithm to see if the current selected move 
        			// is likely to result in a win assuming an optimized opponent
        			int score = MyTools.MinMax(boardState,currentMove, (1-boardState.getOpponent()), (1-boardState.getOpponent()));
        			if(score==1) {
        				myMove = currentMove;
        				break;
        			}
        		}
        		else {
        			avoidDanger = 1;
        			myMove = boardState.getAllLegalMoves().get(dangerCheck);
        			break;
        		}
        		
        	}
        	
        }
    	

        
        //
    	
        // Return your move to be processed by the server.
        return myMove;
    }
}